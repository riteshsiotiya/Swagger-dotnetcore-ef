﻿using AllCargoApiPoc.DB;
using AllCargoApiPoc.Model;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AllCargoApiPoc.Services
{
    public class SailingSchedulesService
    {
        public readonly AllCargoDBContext _dbContext;
        public readonly ILogger<object> _logger;
        public SailingSchedulesService(AllCargoDBContext dbContext, ILogger<object> logger)
        {
            _dbContext = dbContext;
            _logger = logger;
        }
        public IEnumerable<tblSchedule> GetSailingSchedule(string fromCode, string toCode)
        {
            IEnumerable<tblSchedule> result = null;
            try
            {
                bool isFromContryCode = ValidateForCountryCode(fromCode);
                bool isToContryCode = ValidateForCountryCode(toCode);

                List<string> UNLocationCodeListDestination = null;
                List<string> UNLocationCodeListSource = null;

                if (isFromContryCode)
                {
                    UNLocationCodeListSource = GetUNLocationCodeForCountryCode(fromCode);
                }
                if (isToContryCode)
                {
                    UNLocationCodeListDestination = GetUNLocationCodeForCountryCode(toCode);
                }

                if (isFromContryCode && isToContryCode)
                {
                    result = _dbContext.tblSchedules.Where(x => UNLocationCodeListSource.Contains(x.PORUNCode)
                    && UNLocationCodeListDestination.Contains(x.PODUNCode)).ToList();
                }
                if (!isFromContryCode && !isToContryCode)
                {
                    result = _dbContext.tblSchedules.ToList().Where(x => x.PORUNCode == fromCode
                         && x.PODUNCode == toCode).ToList();
                }
                if (isFromContryCode && !isToContryCode)
                {
                    result = _dbContext.tblSchedules.ToList().Where(x => UNLocationCodeListSource.Contains(x.PORUNCode)
                        && x.PODUNCode == toCode).ToList();
                }
                if (!isFromContryCode && isToContryCode)
                {
                    result = _dbContext.tblSchedules.ToList().Where(x => x.PORUNCode == fromCode
                        && UNLocationCodeListDestination.Contains(x.PODUNCode)).ToList();
                }
            }
            catch(Exception ex)
            {
                _logger.LogError(ex.StackTrace);
            }
            return result;
        }

        private bool ValidateForCountryCode(string code)
        {
            return code.Length == 2 ? true : false;
        }

        private List<string> GetUNLocationCodeForCountryCode(string countryCode)
        {
            return _dbContext.tblCountryUNLocations.Where(x => x.CountryCode==countryCode)
                .Select(x => x.UNLocationCode).ToList();
        }
    }
}