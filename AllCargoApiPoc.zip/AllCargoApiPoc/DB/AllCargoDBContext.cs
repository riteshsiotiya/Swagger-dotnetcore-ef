﻿using AllCargoApiPoc.Model;
using Microsoft.EntityFrameworkCore;

namespace AllCargoApiPoc.DB
{
    public class AllCargoDBContext : DbContext
    {
        public AllCargoDBContext(DbContextOptions<AllCargoDBContext> options) : base(options)
        {
        }
        public DbSet<tblSchedule> tblSchedules { get; set; }
        public DbSet<tblCountryUNLocation> tblCountryUNLocations { get; set; }
    }
       
}
