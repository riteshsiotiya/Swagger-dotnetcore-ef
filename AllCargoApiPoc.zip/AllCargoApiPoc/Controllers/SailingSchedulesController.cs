﻿using AllCargoApiPoc.DB;
using AllCargoApiPoc.Model;
using AllCargoApiPoc.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

namespace AllCargoApiPoc.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/sailing-schedules")]
    public class SailingSchedulesController : Controller
    {
        public readonly AllCargoDBContext _dbContext;
        public readonly SailingSchedulesService _sailingSchedulesService;
        public readonly ILogger<object> _logger;
        public SailingSchedulesController(AllCargoDBContext dbContext, ILogger<object> logger)
        {
            _logger = logger;
            _dbContext = dbContext;
            _sailingSchedulesService = new SailingSchedulesService(_dbContext, logger);
        }

        /// <summary>
        /// This api retrieve sailing schedules basis UN Locations or Country Codes or any combination
        /// </summary>
        /// 
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET api/sailing-schedules
        ///     param:  
        ///     fromCode = USDAL or US
        ///     toCode = BEABS or BE
        /// </remarks>
        /// 
        /// <returns> Sailing schedule list</returns>
        /// <response code="401">UnAuthorize or try again with correct credentils</response> 
        /// <response code="400">Invalid input</response> 
        [HttpGet]
        [ProducesResponseType(401)]
        [ProducesResponseType(400)]
        public ActionResult Get(string fromCode, string toCode)
        {
            IEnumerable<tblSchedule> sailingList = null;
            try
            {
                if (!ValidateCode(fromCode) || !ValidateCode(toCode))
                {
                    return BadRequest();
                }
                sailingList = _sailingSchedulesService.GetSailingSchedule(fromCode, toCode);
            }
            catch (Exception ex)
            {
                _logger.LogError($"input: fromCode:{fromCode}, toCode:{toCode}", ex.StackTrace);
            }
            return Ok(sailingList);
        }

        private bool ValidateCode(string code)
        {
            bool result = false;
            if (!string.IsNullOrWhiteSpace(code))
            {
                result = code.Length == 2 || code.Length == 5 ? true : false;
            }
            return result;
        }
    }
}
