﻿using AllCargoApiPoc.Model;
using Microsoft.AspNetCore.Mvc;
using AllCargoApiPoc.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;
using System;

namespace AllCargoApiPoc.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : Controller
    {
        private readonly IConfiguration _config;
        private readonly IJwtAuthManager _jwtAuthManager;
        private readonly ILogger<object> _logger;
        public LoginController(IConfiguration config, IJwtAuthManager jwtAuthManager, ILogger<object> logger)
        {
            _config = config;
            _jwtAuthManager = jwtAuthManager;
            _logger = logger;
        }

        /// <summary>
        /// Login to generate Token
        /// </summary>
        /// 
        /// <remarks>
        /// Sample request:
        /// 
        ///    POST api/login
        ///    
        ///    body: {
        ///     "email":  "user1@gmail.com",
        ///     "password" :  "password"
        ///     }
        /// </remarks>
        /// <returns> Jwt Bearer token </returns>
        /// <response code="401">UnAuthorize or try again with correct credentils</response>    
        [HttpPost]
        [AllowAnonymous]
        [ProducesResponseType(401)]
        public IActionResult Login([FromBody]LoginRequest login)
        {
            IActionResult response = Unauthorized();
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest();
                }
                var user = AuthenticateUser(login);
                if (user != null)
                {
                    var tokenString = _jwtAuthManager.GenerateJSONWebToken(user);

                    response = Ok(tokenString);
                }
            }
            catch(Exception ex)
            {
                _logger.LogError(ex.StackTrace);
            }
            return response;
        }
        private User AuthenticateUser(LoginRequest login)
        {
            User user = null;
            if (login.Email == "user1@gmail.com" && login.Password == "password")
            {
                user = new User
                {
                    Email=login.Email,
                    Username = "Ritesh",
                };
            }
            return user;
        }
    }
}