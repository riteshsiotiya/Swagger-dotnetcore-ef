﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AllCargoApiPoc.Model
{
    public class tblSchedule
    {
        public int ID { get; set; }
        public string ProductType { get; set; }
        public string PORUNCode { get; set; }
        public string POLUNCode { get; set; }
        public string HUBUNCode { get; set; }
        public string PODUNCode { get; set; }
        public DateTime? CutOff { get; set; }
        public DateTime? CutOffIMO { get; set; }
        public DateTime? ETD { get; set; }
        public DateTime? ETA { get; set; }
        public string TransitTimePortToPort { get; set; }
        public string TransitTimeCutOffToPort { get; set; }
        public string VesselName { get; set; }
        public string IMONumber { get; set; }
        public string VoyageNumber { get; set; }
        public string CarrierSCAC { get; set; }
        public string CarrierName { get; set; }
        public string Comments { get; set; }
    }
}
